#!/bin/bash -x


# https://ebssec.boc.cn
gmssl tlcp_client -host 123.124.191.183

# https://zffw.jxzwfww.gov.cn
gmssl tlcp_client -host 218.87.21.62
